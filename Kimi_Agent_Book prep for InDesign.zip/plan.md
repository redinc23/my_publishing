# Plan: Prepare "We Are Wolf" Manuscript for Adobe InDesign

## Objective
Go through every Pre-InDesign Preparation checklist item from the Checklist Guide and revamp Book 1 - Final.docx into a clean, structured, InDesign-ready document.

## Stage 1: Full Manuscript Audit & Structure Mapping
- Read the complete manuscript to map all chapters, parts, front matter, back matter
- Identify all inline images and their locations
- Note any structural issues (missing elements, ordering, etc.)
- Document current formatting state

## Stage 2: Manuscript Cleanup (per Checklist Section 1.2)
- Remove manual page breaks
- Standardize heading styles (Heading 1 for chapters, Heading 2 for parts)
- Apply consistent body text style
- Replace inline images with [IMAGE: filename.jpg] placeholders
- Verify/fix italic formatting (not underlined or colored)
- Fix straight quotes → typographic curly quotes
- Fix double spaces → single spaces
- Fix double hyphens → em-dashes
- Fix number ranges → en-dashes
- Fix three periods → ellipsis
- Add consistent figure captions

## Stage 3: Typography & Formatting Validation
- Spell check / grammar check equivalent
- Verify all typographic fixes
- Ensure consistent paragraph styling
- Validate image placeholders
- Confirm front matter and back matter completeness

## Stage 4: Final Output
- Save as clean .docx with all formatting preserved
- Save as plain-text version for emergency reference
- Deliver the InDesign-ready manuscript
